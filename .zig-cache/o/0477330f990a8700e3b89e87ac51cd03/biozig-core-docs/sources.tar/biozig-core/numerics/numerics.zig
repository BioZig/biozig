const std = @import("std");

/// Computes the sum of a float slice stably using the Kahan summation algorithm.
pub fn kahanSum(slice: []const f64) f64 {
    var sum: f64 = 0.0;
    var c: f64 = 0.0;
    for (slice) |x| {
        const y = x - c;
        const t = sum + y;
        c = (t - sum) - y;
        sum = t;
    }
    return sum;
}

/// Computes the mean of a float slice.
pub fn mean(slice: []const f64) f64 {
    if (slice.len == 0) return 0.0;
    return kahanSum(slice) / @as(f64, @floatFromInt(slice.len));
}

/// Computes the sample variance of a float slice.
pub fn variance(slice: []const f64) f64 {
    if (slice.len < 2) return 0.0;
    var count: f64 = 0.0;
    var m: f64 = 0.0;
    var m2: f64 = 0.0;
    for (slice) |x| {
        count += 1.0;
        const delta = x - m;
        m += delta / count;
        const delta2 = x - m;
        m2 += delta * delta2;
    }
    return m2 / (count - 1.0);
}

/// Computes the sample covariance between two float slices of equal length.
pub fn covariance(x: []const f64, y: []const f64) f64 {
    std.debug.assert(x.len == y.len);
    if (x.len < 2) return 0.0;
    const x_mean = mean(x);
    const y_mean = mean(y);
    var sum: f64 = 0.0;
    var c: f64 = 0.0;
    for (0..x.len) |i| {
        const val = (x[i] - x_mean) * (y[i] - y_mean);
        const term = val - c;
        const t = sum + term;
        c = (t - sum) - term;
        sum = t;
    }
    return sum / @as(f64, @floatFromInt(x.len - 1));
}

/// Computes the p-th quantile of a float slice using the standard R-7 method.
/// p must be in the range [0.0, 1.0].
pub fn quantile(slice: []const f64, p: f64, allocator: std.mem.Allocator) !f64 {
    std.debug.assert(p >= 0.0 and p <= 1.0);
    if (slice.len == 0) return 0.0;
    if (slice.len == 1) return slice[0];

    const copy = try allocator.alloc(f64, slice.len);
    defer allocator.free(copy);
    @memcpy(copy, slice);
    std.sort.block(f64, copy, {}, std.sort.asc(f64));

    const h = @as(f64, @floatFromInt(copy.len - 1)) * p;
    const index = @as(usize, @intFromFloat(@floor(h)));
    const frac = h - @floor(h);

    if (index >= copy.len - 1) {
        return copy[copy.len - 1];
    }
    return copy[index] + frac * (copy[index + 1] - copy[index]);
}

test "kahan summation stability" {
    const vals = [_]f64{ 1.0, 1e10, 1.0, -1e10 };
    try std.testing.expectEqual(kahanSum(&vals), 2.0);
}

test "mean, variance, covariance" {
    const x = [_]f64{ 2.0, 4.0, 4.0, 4.0, 5.0, 5.0, 7.0, 9.0 };
    const y = [_]f64{ 1.0, 3.0, 2.0, 4.0, 3.0, 4.0, 6.0, 8.0 };

    try std.testing.expectApproxEqAbs(@as(f64, 5.0), mean(&x), 1e-5);
    try std.testing.expectApproxEqAbs(@as(f64, 4.571428571428571), variance(&x), 1e-5);
    try std.testing.expectApproxEqAbs(@as(f64, 4.571428571428571), covariance(&x, &y), 1e-5);
}

test "quantiles" {
    const data = [_]f64{ 3.0, 6.0, 7.0, 8.0, 8.0, 10.0, 13.0, 15.0, 16.0, 20.0 };
    const q25 = try quantile(&data, 0.25, std.testing.allocator);
    const q50 = try quantile(&data, 0.50, std.testing.allocator);
    const q75 = try quantile(&data, 0.75, std.testing.allocator);

    try std.testing.expectApproxEqAbs(@as(f64, 7.25), q25, 1e-5);
    try std.testing.expectApproxEqAbs(@as(f64, 9.0), q50, 1e-5);
    try std.testing.expectApproxEqAbs(@as(f64, 14.5), q75, 1e-5);
}
