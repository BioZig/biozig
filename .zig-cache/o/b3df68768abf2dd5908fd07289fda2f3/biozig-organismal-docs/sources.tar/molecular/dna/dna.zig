const std = @import("std");
const sequence = @import("../sequence/sequence.zig");

/// Nucleotide representation for 2-bit DNA.
pub const Nucleotide = enum(u2) {
    A = 0b00,
    C = 0b01,
    G = 0b10,
    T = 0b11,
};

/// IUPAC Ambiguity Codes for 4-bit DNA.
/// Using bitmasks where A=1, C=2, G=4, T=8.
pub const IUPAC = enum(u4) {
    A = 1,
    C = 2,
    G = 4,
    T = 8,
    R = 1 | 4,       // A or G
    Y = 2 | 8,       // C or T
    S = 2 | 4,       // G or C
    W = 1 | 8,       // A or T
    K = 4 | 8,       // G or T
    M = 1 | 2,       // A or C
    B = 2 | 4 | 8,   // C or G or T
    D = 1 | 4 | 8,   // A or G or T
    H = 1 | 2 | 8,   // A or C or T
    V = 1 | 2 | 4,   // A or C or G
    N = 1 | 2 | 4 | 8, // Any base
};

pub fn charToNucleotide(c: u8) !Nucleotide {
    return switch (c) {
        'A', 'a' => .A,
        'C', 'c' => .C,
        'G', 'g' => .G,
        'T', 't' => .T,
        else => error.InvalidNucleotide,
    };
}

pub fn nucleotideToChar(n: Nucleotide) u8 {
    return switch (n) {
        .A => 'A',
        .C => 'C',
        .G => 'G',
        .T => 'T',
    };
}

pub fn charToIUPAC(c: u8) !IUPAC {
    return switch (c) {
        'A', 'a' => .A,
        'C', 'c' => .C,
        'G', 'g' => .G,
        'T', 't', 'U', 'u' => .T,
        'R', 'r' => .R,
        'Y', 'y' => .Y,
        'S', 's' => .S,
        'W', 'w' => .W,
        'K', 'k' => .K,
        'M', 'm' => .M,
        'B', 'b' => .B,
        'D', 'd' => .D,
        'H', 'h' => .H,
        'V', 'v' => .V,
        'N', 'n' => .N,
        else => error.InvalidIUPACCode,
    };
}

pub fn iupacToChar(i: IUPAC) u8 {
    return switch (i) {
        .A => 'A',
        .C => 'C',
        .G => 'G',
        .T => 'T',
        .R => 'R',
        .Y => 'Y',
        .S => 'S',
        .W => 'W',
        .K => 'K',
        .M => 'M',
        .B => 'B',
        .D => 'D',
        .H => 'H',
        .V => 'V',
        .N => 'N',
    };
}

/// 2-bit packed DNA representation.
pub const DNA2 = struct {
    bytes: []u8,
    len: usize,
    allocator: std.mem.Allocator,

    pub fn init(str: []const u8, allocator: std.mem.Allocator) !DNA2 {
        const num_bytes = (str.len * 2 + 7) / 8;
        const bytes = try allocator.alloc(u8, num_bytes);
        errdefer allocator.free(bytes);

        var self = DNA2{
            .bytes = bytes,
            .len = str.len,
            .allocator = allocator,
        };
        const p = self.packer();
        for (str, 0..) |char, i| {
            const n = try charToNucleotide(char);
            p.set(i, @intFromEnum(n));
        }
        return self;
    }

    pub fn deinit(self: *DNA2) void {
        self.allocator.free(self.bytes);
    }

    pub fn view(self: DNA2) DNA2View {
        return .{
            .bytes = self.bytes,
            .start = 0,
            .len = self.len,
        };
    }

    pub fn get(self: DNA2, index: usize) Nucleotide {
        return self.view().get(index);
    }

    pub fn slice(self: DNA2, start: usize, end: usize) DNA2View {
        return self.view().slice(start, end);
    }

    pub fn packer(self: DNA2) @import("core").bitpacking.PackedIntArray(2) {
        return @import("core").bitpacking.PackedIntArray(2).init(self.bytes, self.len);
    }
};

/// Read-only zero-copy view of a DNA2 sequence.
pub const DNA2View = struct {
    bytes: []const u8,
    start: usize,
    len: usize,

    pub fn get(self: DNA2View, index: usize) Nucleotide {
        std.debug.assert(index < self.len);
        const bit_offset = (self.start + index) * 2;
        const byte_index = bit_offset / 8;
        const bit_shift = @as(u3, @truncate(bit_offset % 8));
        const mask = @as(u32, 0b11);
        var val: u32 = self.bytes[byte_index];
        if (@as(usize, bit_shift) + 2 > 8) {
            val |= @as(u32, self.bytes[byte_index + 1]) << 8;
        }
        const enum_val = @as(u2, @truncate((val >> bit_shift) & mask));
        return @enumFromInt(enum_val);
    }

    pub fn slice(self: DNA2View, start: usize, end: usize) DNA2View {
        std.debug.assert(start <= end and end <= self.len);
        return .{
            .bytes = self.bytes,
            .start = self.start + start,
            .len = end - start,
        };
    }

    pub fn iterator(self: DNA2View) sequence.Iterator(DNA2View) {
        return .{ .seq = self };
    }

    pub fn reverse(self: DNA2View, allocator: std.mem.Allocator) !DNA2 {
        const num_bytes = (self.len * 2 + 7) / 8;
        const bytes = try allocator.alloc(u8, num_bytes);
        errdefer allocator.free(bytes);

        var res = DNA2{ .bytes = bytes, .len = self.len, .allocator = allocator };
        const packer = res.packer();
        for (0..self.len) |i| {
            packer.set(i, @intFromEnum(self.get(self.len - 1 - i)));
        }
        return res;
    }

    pub fn complement(self: DNA2View, allocator: std.mem.Allocator) !DNA2 {
        const num_bytes = (self.len * 2 + 7) / 8;
        const bytes = try allocator.alloc(u8, num_bytes);
        errdefer allocator.free(bytes);

        var res = DNA2{ .bytes = bytes, .len = self.len, .allocator = allocator };
        const packer = res.packer();
        for (0..self.len) |i| {
            const val = @intFromEnum(self.get(i));
            packer.set(i, ~val);
        }
        return res;
    }

    pub fn reverseComplement(self: DNA2View, allocator: std.mem.Allocator) !DNA2 {
        const num_bytes = (self.len * 2 + 7) / 8;
        const bytes = try allocator.alloc(u8, num_bytes);
        errdefer allocator.free(bytes);

        var res = DNA2{ .bytes = bytes, .len = self.len, .allocator = allocator };
        const packer = res.packer();
        for (0..self.len) |i| {
            const val = @intFromEnum(self.get(self.len - 1 - i));
            packer.set(i, ~val);
        }
        return res;
    }

    pub fn equals(self: DNA2View, other: DNA2View) bool {
        return sequence.equal(self, other);
    }

    pub fn hash(self: DNA2View) u64 {
        return sequence.hash(self);
    }

    pub fn gcContent(self: DNA2View) f64 {
        if (self.len == 0) return 0.0;
        var gc_count: usize = 0;
        for (0..self.len) |i| {
            const n = self.get(i);
            if (n == .G or n == .C) {
                gc_count += 1;
            }
        }
        return @as(f64, @floatFromInt(gc_count)) / @as(f64, @floatFromInt(self.len));
    }

    pub const Counts = struct {
        a: usize = 0,
        c: usize = 0,
        g: usize = 0,
        t: usize = 0,
    };

    pub fn counts(self: DNA2View) Counts {
        var res = Counts{};
        for (0..self.len) |i| {
            switch (self.get(i)) {
                .A => res.a += 1,
                .C => res.c += 1,
                .G => res.g += 1,
                .T => res.t += 1,
            }
        }
        return res;
    }

    pub fn kmers(self: DNA2View, k: usize) sequence.KmerIterator(DNA2View) {
        return .{ .view = self, .k = k };
    }

    pub fn serialize(self: DNA2View, writer: anytype) !void {
        const serializeBinary = @import("core").serialization.serialize;
        try serializeBinary(writer, @as(u64, self.len));
        var byte_val: u8 = 0;
        for (0..self.len) |i| {
            const bit_idx = i % 4;
            const n = self.get(i);
            byte_val |= @as(u8, @intFromEnum(n)) << @as(u3, @truncate(bit_idx * 2));
            if (bit_idx == 3 or i == self.len - 1) {
                try writer.writeByte(byte_val);
                byte_val = 0;
            }
        }
    }

    pub fn deserialize(reader: anytype, allocator: std.mem.Allocator) !DNA2 {
        const deserializeBinary = @import("core").serialization.deserialize;
        const len = try deserializeBinary(reader, u64, allocator);
        const num_bytes = (len * 2 + 7) / 8;
        const bytes = try allocator.alloc(u8, num_bytes);
        errdefer allocator.free(bytes);

        var res = DNA2{ .bytes = bytes, .len = len, .allocator = allocator };
        const p = res.packer();

        var byte_val: u8 = 0;
        for (0..len) |i| {
            const bit_idx = i % 4;
            if (bit_idx == 0) {
                var b: [1]u8 = undefined;
                try reader.readSliceAll(&b);
                byte_val = b[0];
            }
            const n_val = @as(u2, @truncate(byte_val >> @as(u3, @truncate(bit_idx * 2))));
            p.set(i, n_val);
        }
        return res;
    }
};

/// 4-bit packed IUPAC DNA representation.
pub const DNA4 = struct {
    bytes: []u8,
    len: usize,
    allocator: std.mem.Allocator,

    pub fn init(str: []const u8, allocator: std.mem.Allocator) !DNA4 {
        const num_bytes = (str.len * 4 + 7) / 8;
        const bytes = try allocator.alloc(u8, num_bytes);
        errdefer allocator.free(bytes);

        var self = DNA4{
            .bytes = bytes,
            .len = str.len,
            .allocator = allocator,
        };
        const p = self.packer();
        for (str, 0..) |char, i| {
            const val = try charToIUPAC(char);
            p.set(i, @intFromEnum(val));
        }
        return self;
    }

    pub fn deinit(self: *DNA4) void {
        self.allocator.free(self.bytes);
    }

    pub fn view(self: DNA4) DNA4View {
        return .{
            .bytes = self.bytes,
            .start = 0,
            .len = self.len,
        };
    }

    pub fn get(self: DNA4, index: usize) IUPAC {
        return self.view().get(index);
    }

    pub fn slice(self: DNA4, start: usize, end: usize) DNA4View {
        return self.view().slice(start, end);
    }

    pub fn packer(self: DNA4) @import("core").bitpacking.PackedIntArray(4) {
        return @import("core").bitpacking.PackedIntArray(4).init(self.bytes, self.len);
    }
};

/// Read-only zero-copy view of a DNA4 sequence.
pub const DNA4View = struct {
    bytes: []const u8,
    start: usize,
    len: usize,

    pub fn get(self: DNA4View, index: usize) IUPAC {
        std.debug.assert(index < self.len);
        const bit_offset = (self.start + index) * 4;
        const byte_index = bit_offset / 8;
        const bit_shift = @as(u3, @truncate(bit_offset % 8));
        const mask = @as(u32, 0b1111);
        var val: u32 = self.bytes[byte_index];
        if (@as(usize, bit_shift) + 4 > 8) {
            val |= @as(u32, self.bytes[byte_index + 1]) << 8;
        }
        const enum_val = @as(u4, @truncate((val >> bit_shift) & mask));
        return @enumFromInt(enum_val);
    }

    pub fn slice(self: DNA4View, start: usize, end: usize) DNA4View {
        std.debug.assert(start <= end and end <= self.len);
        return .{
            .bytes = self.bytes,
            .start = self.start + start,
            .len = end - start,
        };
    }

    pub fn iterator(self: DNA4View) sequence.Iterator(DNA4View) {
        return .{ .seq = self };
    }

    pub fn reverse(self: DNA4View, allocator: std.mem.Allocator) !DNA4 {
        const num_bytes = (self.len * 4 + 7) / 8;
        const bytes = try allocator.alloc(u8, num_bytes);
        errdefer allocator.free(bytes);

        var res = DNA4{ .bytes = bytes, .len = self.len, .allocator = allocator };
        const packer = res.packer();
        for (0..self.len) |i| {
            packer.set(i, @intFromEnum(self.get(self.len - 1 - i)));
        }
        return res;
    }

    pub fn complement(self: DNA4View, allocator: std.mem.Allocator) !DNA4 {
        const num_bytes = (self.len * 4 + 7) / 8;
        const bytes = try allocator.alloc(u8, num_bytes);
        errdefer allocator.free(bytes);

        var res = DNA4{ .bytes = bytes, .len = self.len, .allocator = allocator };
        const packer = res.packer();
        for (0..self.len) |i| {
            packer.set(i, @intFromEnum(complementIUPAC(self.get(i))));
        }
        return res;
    }

    pub fn reverseComplement(self: DNA4View, allocator: std.mem.Allocator) !DNA4 {
        const num_bytes = (self.len * 4 + 7) / 8;
        const bytes = try allocator.alloc(u8, num_bytes);
        errdefer allocator.free(bytes);

        var res = DNA4{ .bytes = bytes, .len = self.len, .allocator = allocator };
        const packer = res.packer();
        for (0..self.len) |i| {
            packer.set(i, @intFromEnum(complementIUPAC(self.get(self.len - 1 - i))));
        }
        return res;
    }

    pub fn complementIUPAC(i: IUPAC) IUPAC {
        const val = @intFromEnum(i);
        var res: u4 = 0;
        if (val & 0b0001 != 0) res |= 0b1000;
        if (val & 0b0010 != 0) res |= 0b0100;
        if (val & 0b0100 != 0) res |= 0b0010;
        if (val & 0b1000 != 0) res |= 0b0001;
        return @enumFromInt(res);
    }

    pub fn equals(self: DNA4View, other: DNA4View) bool {
        return sequence.equal(self, other);
    }

    pub fn hash(self: DNA4View) u64 {
        return sequence.hash(self);
    }

    pub fn gcContent(self: DNA4View) f64 {
        if (self.len == 0) return 0.0;
        var gc_weight: f64 = 0.0;
        for (0..self.len) |i| {
            gc_weight += getGCWeight(self.get(i));
        }
        return gc_weight / @as(f64, @floatFromInt(self.len));
    }

    fn getGCWeight(i: IUPAC) f64 {
        return switch (i) {
            .A, .T => 0.0,
            .C, .G, .S => 1.0,
            .R, .Y, .K, .M, .N => 0.5,
            .W => 0.0,
            .B, .V => 2.0 / 3.0,
            .D, .H => 1.0 / 3.0,
        };
    }

    pub const Counts = struct {
        a: usize = 0,
        c: usize = 0,
        g: usize = 0,
        t: usize = 0,
        other: usize = 0,
    };

    pub fn counts(self: DNA4View) Counts {
        var res = Counts{};
        for (0..self.len) |i| {
            switch (self.get(i)) {
                .A => res.a += 1,
                .C => res.c += 1,
                .G => res.g += 1,
                .T => res.t += 1,
                else => res.other += 1,
            }
        }
        return res;
    }

    pub fn kmers(self: DNA4View, k: usize) sequence.KmerIterator(DNA4View) {
        return .{ .view = self, .k = k };
    }

    pub fn serialize(self: DNA4View, writer: anytype) !void {
        const serializeBinary = @import("core").serialization.serialize;
        try serializeBinary(writer, @as(u64, self.len));
        var byte_val: u8 = 0;
        for (0..self.len) |i| {
            const bit_idx = i % 2;
            const n = self.get(i);
            byte_val |= @as(u8, @intFromEnum(n)) << @as(u3, @truncate(bit_idx * 4));
            if (bit_idx == 1 or i == self.len - 1) {
                try writer.writeByte(byte_val);
                byte_val = 0;
            }
        }
    }

    pub fn deserialize(reader: anytype, allocator: std.mem.Allocator) !DNA4 {
        const deserializeBinary = @import("core").serialization.deserialize;
        const len = try deserializeBinary(reader, u64, allocator);
        const num_bytes = (len * 4 + 7) / 8;
        const bytes = try allocator.alloc(u8, num_bytes);
        errdefer allocator.free(bytes);

        var res = DNA4{ .bytes = bytes, .len = len, .allocator = allocator };
        const p = res.packer();

        var byte_val: u8 = 0;
        for (0..len) |i| {
            const bit_idx = i % 2;
            if (bit_idx == 0) {
                var b: [1]u8 = undefined;
                try reader.readSliceAll(&b);
                byte_val = b[0];
            }
            const n_val = @as(u4, @truncate(byte_val >> @as(u3, @truncate(bit_idx * 4))));
            p.set(i, n_val);
        }
        return res;
    }
};
